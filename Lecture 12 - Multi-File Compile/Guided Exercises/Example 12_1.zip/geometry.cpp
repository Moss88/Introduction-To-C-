
// Define some functions below
double triArea(double base, double height)
{
	return base * height * .5;
}

double rectArea(double width, double height)
{
	return width * height;
}