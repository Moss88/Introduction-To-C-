#include "Book.h"
#include "Library.h"
#include "Customer.h"

void printMenu();

int main()
{
	Library lib;
	int select = 0;
	
	lib.fBooks = "books.txt";

	// Load Books
	if(!loadBooks(lib.fBooks, lib.books, lib.maxBooks, lib.numBooks))
	{
		cout << "Failed to Load Books" << endl;
		return 0;
	}

	// Load Customers
	// Not Implemented

	// Menu
	while(select != 6)
	{
		printMenu();
		cin >> select;
		cout << endl;

		if(select == 1)
		{
			// List Books
			printBooks(lib.books, lib.numBooks);
		}
		else if(select == 2)
		{
			// Add Book To Deposit
			cout << "Book Title: ";
			cin.ignore();
			getline(cin, lib.books[lib.numBooks].title);

			cout << "Year Published: ";
			cin >> lib.books[lib.numBooks].yearPublished;
			
			cout << "Number of Pages: ";
			cin >> lib.books[lib.numBooks].pages;
			
			lib.books[lib.numBooks].checkedOut = false;
			lib.numBooks++;
			
			cout << "Book added." << endl << endl;
		}
		
		// Following Aren't Implemented
		// Check Out Book
		// List Customer
		// Add Customer
	}

	// Write Books Back To File
	writeBooks(lib.fBooks, lib.books, lib.numBooks);

	// Write Customers Back To File
	// Not Implemented

	return 0;
}

void printMenu()
{
	cout << "Select an Option:" << endl;
	cout << "1: List Books" << endl;
	cout << "2: Add Book to Library" << endl;
	//cout << "3: Checkout Book" << endl;
	//cout << "4: List Customers" << endl;
	//cout << "5: Add Customer" << endl;
	cout << "6: Exit" << endl;
}