#include "Book.h"
#include "Library.h"
#include "Customer.h"
int main()
{
	
	// Load Books
	
	// Load Customers

	// Menu
		// List Books
		// Add Book To Deposit
		// Check Out Book
		
		// List Customer
		// Add Customer

		// Exit


	// Write Books Back To File

	// Write Customers Back To File

	return 0;
}