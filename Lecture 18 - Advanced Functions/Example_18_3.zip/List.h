#include<iostream>
using namespace std;

// Each Node contains a generic Element
template <class T> class Node {
public:
	Node();
	~Node();
	T element;
	Node *next;	
};

// Very Rudimentry implementation
// can only add and delete from the front
template <class T> class List {
public:
	List();
	virtual ~List();
	void add(T);
	void remove();
	Node<T> *head;	
};


// Methods for List Class

// Initializes the list to be empty
template <class T> 
List<T>::List()
{
	this->head = NULL;
}

// Add an element to the list
template <class T>
void List<T>::add(T element)
{
	Node<T> *newNd = new Node<T>();
	newNd->element = element;
	newNd->next = this->head;
	this->head = newNd;
}

// Remove a node from the front
template <class T>
void List<T>::remove()
{
	// Dont remove whats not there
	if(this->head == NULL)
		return;

	Node<T> *tmpNd = this->head->next;
	delete head;
	head = tmpNd;
}

// Clean up our dynamic memory
template <class T> List<T>::~List()
{
	while(head != NULL)
		remove();			
}


// Methods for Node Class
template <class T>
Node<T>::Node()
{
	this->next = NULL;
}

template <class T>
Node<T>::~Node()
{
}

