#include "List.h"

int main()
{
	// Create a list of ints
	List<int> myList;
	Node<int> *nd;

	myList.add(10);
	myList.add(15);
	myList.add(20);

	nd = myList.head;
	while(nd != NULL)
	{
		cout << nd->element << endl;
		nd = nd->next;
	}

	myList.remove();
	while(nd != NULL)
	{
		cout << nd->element << endl;
		nd = nd->next;
	}

	return 0;
}