#include "linkedList.h"
#include <iostream>
Node* addItem(Node *list, string itemName)
{
	Node *newItem = new Node; // gen new node
	newItem->itemName = itemName; 
	newItem->next = list; // point it to old head
	return newItem; // return new head
}


Node* removeHead(Node *list)
{
	// Save pointer of next element
	Node *head = list->next;
	delete list; // delete head element
	return head; // return new head
}

Node* removeItem(Node *list, string itemName)
{
	Node *prev = NULL, *cur;

	// Check first node first
	if(list->itemName == itemName)
		return removeHead(list);
	
	// Check rest of list
	cur = list->next;
	while(cur != NULL)
	{
		if(cur->itemName == itemName)
		{
			// Set the previous to currents next
			prev->next = cur->next;
			delete cur;
			return list;
		}
		// Save cur to previous
		prev = cur;
		cur = cur->next;
	}
	// At this point the item was not found
	return list;
}


void printList(Node *list)
{
	while(list != NULL)
	{
		cout << list->itemName << endl;
		list = list->next;
	}
}

void freeList(Node *list)
{
	// Keep removing the head until
	// the list is empty
	while(list != NULL)
		list = removeHead(list);
}