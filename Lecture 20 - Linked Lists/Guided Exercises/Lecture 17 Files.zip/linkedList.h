#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include<string>
using namespace std;
struct Node {
	string itemName;
	Node *next;
};

// Prototypes
Node* addItem(Node *, string);
void printList(Node *);
Node* removeHead(Node *);
Node* removeItem(Node *, string);
void freeList(Node *);


#endif