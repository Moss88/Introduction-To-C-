#include<iostream>
#include "linkedList.h"

using namespace std;

int main ()
{
	Node *myList = NULL;
	myList = addItem(myList, "orange");
	myList = addItem(myList, "apple");
	myList = addItem(myList, "milk");
	cout << "List with three items:" << endl;
	printList(myList);

	myList = removeHead(myList);
	cout << endl << "List with two items:" << endl;
	printList(myList);

	myList = addItem(myList, "honey");
	myList = addItem(myList, "waffles");
	cout << endl << "List after honey and waffles were added:" << endl; 
	printList(myList);

	myList = removeItem(myList, "apple");
	cout << endl << "List after apple is removed:" << endl;
	printList(myList);

	freeList(myList);

	return 0;
}